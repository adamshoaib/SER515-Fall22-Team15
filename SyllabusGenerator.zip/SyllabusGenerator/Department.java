public class Department extends SyllabusBuilder {

	public void approveOrReject() {

	}

	public void updatePolicy() {

	}

	public void setFaculty() {

	}

	public void setCourseName() {

	}

	public void setCourseId() {

	}

	public void viewSyllabus() {

	}

}
