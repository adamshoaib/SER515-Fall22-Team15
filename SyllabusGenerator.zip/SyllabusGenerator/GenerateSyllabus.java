public interface GenerateSyllabus {

	public SyllabusDecorator syllabusDecorator = null;

	public abstract void generateSyllabus();

}
