public class Timer {

	private TimerObject timerObject;

	public void main() {

	}

}
