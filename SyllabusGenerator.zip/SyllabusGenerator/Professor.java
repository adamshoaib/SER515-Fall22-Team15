public class Professor implements GenerateSyllabus {

	public void generateSyllabus() {

	}

}
