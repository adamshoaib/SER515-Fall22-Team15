public class SyllabusGenerator {

	private list courselist;

	private SyllabusDatabase syllabusDatabase;

	private SyllabusCreatorFacade syllabusCreatorFacade;

	public void createsyllabus() {

	}

	public void sendforApproval() {

	}

	public void createSyllabus() {

	}

	public void updateSyllabus() {

	}

	public void viewSyllabus() {

	}

	public void setCourseID() {

	}

	public void setCourseName() {

	}

	public void setFaculty() {

	}

	public void approveOrReject() {

	}

	public void updatePolicy() {

	}

	public void addComments() {

	}

}
