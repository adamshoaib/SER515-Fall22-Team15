public class Syllabus {

	private SyllabusBuilder syllabusBuilder;

}
