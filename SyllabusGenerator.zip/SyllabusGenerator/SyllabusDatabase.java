public class SyllabusDatabase {

	private list courselist;

	private boolean edit;

	private SyllabusGenerator syllabusGenerator;

	public void converttoLMS() {

	}

}
