public class TimerObject {

	private TimerObject instance;

	private Timer timer;

	public void sendNotification() {

	}

	public void modifyCalender() {

	}

	public void getInstance() {

	}

	public void checkForChanges() {

	}

}
