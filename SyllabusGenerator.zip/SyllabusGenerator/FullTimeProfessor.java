public class FullTimeProfessor extends Professor {

	public void generateSyllabus() {

	}

}
