public class AdjuntProfessor extends Professor {

	public void generateSyllabus() {

	}

}
