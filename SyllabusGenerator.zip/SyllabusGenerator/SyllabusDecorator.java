public abstract class SyllabusDecorator implements GenerateSyllabus {

	private GenerateSyllabus generateSyllabus;

	public void generateSyllabus() {
		System.out.println("Inside generateSyllabus");
	}

}
