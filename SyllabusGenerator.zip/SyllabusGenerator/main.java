public class main {
        public static void main(String args[]) {

            SyllabusDecorator existingSyllabus = new ExistingVersion();
            existingSyllabus.generateSyllabus();
            SyllabusGeneratorAdapter sga = new SyllabusGeneratorAdapter();
            CanvasDatabase c = new CanvasDatabase();
            char k = sga.converttoLMS();
            Policy pol=new Policy();
            pol.getPolicy();
            pol.addpolicy();
            SyllabusBuilder prof= new Proffessor();
            prof.viewSyllabus();
            SyllabusBuilder dep=new Department();
            dep.viewSyllabus();

    }
}