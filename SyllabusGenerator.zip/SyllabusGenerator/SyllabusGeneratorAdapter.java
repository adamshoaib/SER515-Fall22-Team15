public class SyllabusGeneratorAdapter {

	private CanvasDatabase canvasDatabase;

	public char converttoLMS() {
		System.out.println("Inside converttoLMS");
		return Character.toUpperCase('a');
	}

}
