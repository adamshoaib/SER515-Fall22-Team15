public class Policy {

	private SyllabusCreatorFacade syllabusCreatorFacade;

	public void getPolicy() {

	}

	public void addpolicy() {

	}

}
