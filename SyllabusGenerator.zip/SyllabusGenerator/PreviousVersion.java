public class PreviousVersion extends SyllabusDecorator {

	public void generateSyllabus() {

	}

	public void getPreviousVersion() {

	}

}
