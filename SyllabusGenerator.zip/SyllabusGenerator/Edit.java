public class Edit {

	private boolean edit;

	private SyllabusCreatorFacade syllabusCreatorFacade;

	public void editsyllabus() {

	}

}
