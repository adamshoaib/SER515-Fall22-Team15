public class Proffessor extends SyllabusBuilder {

	public void updateSyllabus() {

	}

	public void sendForApproval() {

	}

	public void viewSyllabus() {

	}

}
