public class CourseList {

	private list showcourses;

	private SyllabusCreatorFacade syllabusCreatorFacade;

	public void DiaplayCourses() {

	}

	public void SelectCourse() {

	}

}
