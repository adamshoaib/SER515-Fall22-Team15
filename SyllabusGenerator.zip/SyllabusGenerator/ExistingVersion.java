public class ExistingVersion extends SyllabusDecorator {

	public void generateSyllabus() {
		System.out.println("Inside generateSyllabus : ExistingVersion");
	}

	public void getExistingVersion() {

	}

}
