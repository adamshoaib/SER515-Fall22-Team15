public class CanvasDatabase {

	private SyllabusGeneratorAdapter syllabusGeneratorAdapter;

}
