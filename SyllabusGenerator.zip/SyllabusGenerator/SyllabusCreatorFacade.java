public class SyllabusCreatorFacade {

	private list courselist;

	private Edit edit;

	private SyllabusGenerator syllabusGenerator;

	private Policy policy;

	private CourseList courseList;

	public void SyllabusGenerator() {

	}

	public void editSyllabus() {

	}

	public void addPolicy() {

	}

	public void createSyllabus() {

	}

	public void publishsyllabus() {

	}

	public void courselist() {

	}

}
