public class Director {

	private SyllabusBuilder syllabusBuilder;

	public void construct(SyllabusBuilder builder) {

	}

}
